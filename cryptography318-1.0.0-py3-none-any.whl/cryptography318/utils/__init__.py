from .misc import extended_gcd

__all__ = [
    "extended_gcd"
]
